/*
Navicat MySQL Data Transfer

Source Server         : jsp
Source Server Version : 50717
Source Host           : 127.0.0.1:3306
Source Database       : jspdemo

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2018-11-27 00:29:57
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `user_name` varchar(100) DEFAULT NULL COMMENT '用户名',
  `password` varchar(17) DEFAULT NULL COMMENT '密码',
  `sex` int(1) DEFAULT NULL COMMENT '性别',
  `no` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '小明', '52614', null, null);
INSERT INTO `user` VALUES ('2', '李四', '52143', null, null);
INSERT INTO `user` VALUES ('3', '大王', '525445', null, null);
INSERT INTO `user` VALUES ('6', '火锅底料', '9654', null, null);
INSERT INTO `user` VALUES ('8', '笑话', '51423', null, null);
INSERT INTO `user` VALUES ('9', '网二三', '9471', null, null);
INSERT INTO `user` VALUES ('11', '龙源', '52164', null, null);
